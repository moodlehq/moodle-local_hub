function prevTopicButton( ) {

	this.clicked = goPrevTopic;
}

var PrevBtn = new prevTopicButton();

function goPrevTopic() {

	PrevPage(''); 
	return 0;

}
