function nextTopicButton( ) {

	this.clicked = goNextTopic;
}

var NextBtn = new nextTopicButton();

function goNextTopic() {

	NextPage(''); 
	return 0;

}
